# DeepSeek Harness 开机动画包

给 [DeepSeek Harness](https://github.com/deepseek-ai)（DSH）桌面端准备的一套双层启动动画。装上之后，打开 DSH 会先播这两段，然后才进聊天界面。

```
① 交互式访问授权序列   ← 要你点两下（可以关掉）
        ↓
② 线稿绘制动画         ← 全自动，纯代码渲染，无视频文件
        ↓
        聊天界面
```

---

## 它长什么样

### ① 交互式访问授权序列

![授权序列](images/01-authorization.png)

黑幕上的 DeepSeek 标识 → 过曝洗白 → 暖白档案底板 → 六步授权流程。

![暖白档案板](images/04-archive-board.png)

六步是：需要访问许可 → 身份资料确认 → 接收访问需求 → 开始读取权限 → 读取完毕·核验通过 → 欢迎访问。

其中**前两步会停下来等你**：

- 第 1 步：点「授予访问权限」或按 `Enter`
- 第 2 步：确认后继续

后四步自动跑完。身份名、编号、权限等级默认是 `JOYCE MOORE / 0087 / 等级 3`，可以改成你自己的。

### ② 线稿绘制动画

![线稿](images/02-line-art.png)

黑底上蓝色发光线条从左往右**逐笔画出人物轮廓**，然后一层三角网格扫过：

![网格](images/03-mesh.png)

接着 `DeepSeek` 标题先以描边态逐字勾出、再填成渐变实心，最后淡出进入聊天。

这一段**没有任何视频文件**，画面全部由 Canvas + CSS 实时渲染，所以不管窗口多大都是清晰的。

---

## 安装

### 前提

- DeepSeek Harness **桌面端**，内核 `0.2.x`（`0.2.0-rc.x` 到 `0.2.1-rc.x` 都行）
- Windows

### 三步

**第 1 步**：把这两个文件放到本机任意一个固定目录（之后别删，卸载前用得到）：

```
dsh-startup-screen-1.1.1.tgz
dsh-procedural-boot-0.1.9.tgz
```

**第 2 步**：打开 DSH → 侧边栏 **插件** → **添加插件**，把上面两个文件的**完整路径**分别填进去安装（不用解压）。

路径示例：

```
C:\Users\你\Downloads\dsh-startup-screen-1.1.1.tgz
C:\Users\你\Downloads\dsh-procedural-boot-0.1.9.tgz
```

**第 3 步**：**完全退出 DSH 再重新打开**。

> 注意是「退出」，不是点窗口的 ✕。DSH 有托盘，点 ✕ 通常只是收进托盘，插件不会重新加载。要右键托盘图标选「退出」，或者任务管理器里结束所有 `DeepSeek Harness.exe`。

### 如果图形界面装不上（命令行备用）

先彻底退出 DSH，然后：

```powershell
cd $env:USERPROFILE\.dsh\profiles\desktop

dsh plugin --profile desktop add "<路径>\dsh-startup-screen-1.1.1.tgz"
dsh plugin --profile desktop add "<路径>\dsh-procedural-boot-0.1.9.tgz"
```

如果提示 `profile "desktop" is managed exclusively by the Electron application`，说明 DSH 进程还在跑，先退干净。

---

## 不想点按钮？关掉交互

默认第一段会停下来等你确认两次。想让它**一口气自动播完**，改一个配置就行。

**做法**：新建这个文件

```
C:\Users\<你的用户名>\.dsh\dsh-startup.json
```

内容：

```json
{
  "requireInteraction": false
}
```

保存后**重启 DSH**。

想恢复成"要点两下"，把 `false` 改成 `true`，或者直接删掉这个文件（删掉即回到默认：需要确认）。

> 这个开关在 DSH 的设置页里也有：**设置 → 启动动画 → 交互 → 需要人工确认**，之后想切随时切。

---

## 想调整什么

### 第一段（授权序列）

**设置 → 启动动画**里能改：

| 分组 | 可调 |
|---|---|
| 播放 | 每次会话 / 总是、速度、是否可跳过 |
| 身份资料 | 身份名称、编号、权限等级 |
| 交互 | **是否要求点击确认** |
| 语音音效 | 语音开关、音色、语速、音调、音量、提示音 |
| 视觉 | 主题、动效强度 |
| 文案 | 中文主字、英文副标题 |

配置落在 `%USERPROFILE%\.dsh\dsh-startup.json`。

### 第二段（线稿动画）

节奏在插件的 `lib/client.template.js` 顶部，单位毫秒：

```js
var T = {
  drawStart: 180,  drawEnd: 2350,    // 线稿绘制
  colorStart: 2350, colorEnd: 3500,  // 全彩淡入
  meshIn: 2100,    meshOut: 3600,    // 三角网格
  stroke: 2150,    fill: 3900,       // 标题描边 → 填色
  outro: 7600,     total: 8200       // 收尾
}
```

改完在该插件目录执行 `node build.mjs` 重新生成，然后用 `dsh plugin add` 装一次新版。

人物占比在同一个文件的 `fitRect()` 里调——`* 1.1` 那个系数越大，人物越满：

```js
var s = Math.min(W / iw, H / ih) * 1.1
```

---

## 两个已知的注意事项

**1. 别同时开第三个开场插件。** 如果你还装了 `dsh-chat-wallpaper` 这类会播全屏视频的插件，要把它设成常驻背景（`placement: "behind"`）而不是第二幕（`"front"`），否则两段动画会叠在一起。

**2. 装完没反应，先硬刷新。** DSH 的客户端资源带长期缓存，升级插件后如果还看到旧画面，在新窗口按 `Ctrl+Shift+R`。还是不行就彻底退出重开。

---

## 卸载

图形界面：插件页里移除这两个插件。

命令行：

```powershell
cd $env:USERPROFILE\.dsh\profiles\desktop
dsh plugin --profile desktop remove dsh-procedural-boot
dsh plugin --profile desktop remove dsh-startup-screen
```

然后打开 `package.json`，把 `dsh.profile.bundles` 数组里对应的两个名字删掉。

---

## 来源与许可

| 组件 | 作者 | 许可 |
|---|---|---|
| `dsh-startup-screen` 1.1.1 | [@6shenhonghong9](https://github.com/6shenhonghong9/dsh-startup-screen) | MIT |
| `dsh-procedural-boot` 0.1.9 | 自建 | MIT |

第一段的视觉设计、真声语音素材版权归原作者所有，这里只是转发安装文件，没有做任何修改。

第二段的角色立绘由使用者自行提供，代码只用它做边缘检测（生成线稿）和淡入，图片以 base64 内联在插件里。

---

## 常见问题

**Q：装完之后什么都没有？**

先确认是不是真的退出了进程。在 PowerShell 里跑：

```powershell
Get-Process 'DeepSeek Harness' | Select Id, StartTime
```

启动时间应该晚于你安装插件的时间。如果还是旧的，说明没退干净。

**Q：第二段动画没出现，只有第一段？**

按 `F12` 打开开发者工具，切到 Console，搜 `dsh-procedural-boot`。正常应该有一行：

```
[dsh-procedural-boot] loaded 0.1.9
```

没有的话说明插件没被加载，检查 `%USERPROFILE%\.dsh\profiles\desktop\package.json` 的 `bundles` 里有没有 `dsh-procedural-boot`。

**Q：第一段播完到第二段之间有黑屏？**

这是正常的。两段之间用一块垫底黑幕衔接，避免闪出聊天界面，大概 0.2~1 秒。

**Q：能只留第二段吗？**

可以。在插件页里禁用 `dsh-startup-screen`（或者从 `bundles` 里删掉它），这样启动后 1.5 秒就会直接开始线稿动画。
